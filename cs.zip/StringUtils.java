

public class test {
	public static boolean allIsNotNull(String... strs){
		boolean ret = true;
		if(strs == null){
			ret = false;
		}else{
			for(String s:strs){
				if(s == null){
					ret = false;
					break;
				}
			}
		}
		return ret;
	}
	public static boolean allIsNotEmpty(String... strs){
		boolean ret = true;
		if(strs == null){
			ret = false;
		}else{
			for(String s : strs){
				if(s == null || s.equals("")){
					ret = false;
					break;
				}
			}
		}
		return ret;
	}
}
