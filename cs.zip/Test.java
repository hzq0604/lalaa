

public class ssss {

	public static void main(String[] args) {
		StringUtils ww = new StringUtils ();
		String[] ss = {"a","b"};
		System.out.println(ww.allIsNotNull(null));
		System.out.println(ww.allIsNotNull(""));
		System.out.println(ww.allIsNotNull("a",null));
		System.out.println(ww.allIsNotNull(ss));
		System.out.println(ww.allIsNotEmpty(null));
		System.out.println(ww.allIsNotEmpty(""));
		System.out.println(ww.allIsNotEmpty("a",null));
		System.out.println(ww.allIsNotEmpty(ss));
		
	}

}
